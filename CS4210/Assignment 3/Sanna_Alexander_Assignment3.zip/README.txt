Alexander J Sanna
Assignment 3 Submission

Kaggle Username: alexsanna
Highest Score Achieved: .70441