public interface QueueInterface<T>
{
	public void enqueue(T newEntry);
}
